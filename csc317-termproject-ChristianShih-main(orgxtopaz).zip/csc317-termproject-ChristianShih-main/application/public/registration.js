if(localStorage.getItem("user")!=null){
  window.location.replace("/");
}

function validate() {
  var user = /^[a-zA-Z][a-zA-Z0-9]{3,42069}/;

  if (!document.myForm.userName.value.match(user)) {
    alert("Please enter correct Username format");
    return false;
  }

  var pass =
    /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,42069}/;

  if (!document.myForm.password.value.match(pass)) {
    alert("Please enter correct password format");
    return false;
  }
  if (document.myForm.confirmPassword.value != document.myForm.password.value) {
    alert("Your password do not matches");
    return false;
  }
  var emailID = document.myForm.email.value;

  atpos = emailID.indexOf("@");
  dotpos = emailID.lastIndexOf(".");

  if (atpos < 1 || dotpos - atpos < 2) {
    alert("Please enter correct email ID");
    return false;
  }
  return true;
}

document.myForm.onsubmit = (e) => {
  e.preventDefault();
  if (validate()) {
    const value = {
      username: document.myForm.userName.value,
      email: document.myForm.email.value,
      password: document.myForm.password.value,
    };
    console.log(validate());
    var xhr = new XMLHttpRequest();
    // url
    xhr.open("POST", "/users/register", true);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onreadystatechange = function () {
      if (this.readyState === 4 && this.status === 200) {
        var jsonResponse = JSON.parse(xhr.response);
        console.log(jsonResponse);
        if (jsonResponse.status === "error") {
          document.myForm.userName.value = "";
          alert(jsonResponse.message);
        } else {
          if (jsonResponse.status === "success") {
            window.location.replace("/login");
          } else {
            alert("Something went wrong !");
          }
        }
      }
    };
    xhr.send(JSON.stringify(value));
  }
};
