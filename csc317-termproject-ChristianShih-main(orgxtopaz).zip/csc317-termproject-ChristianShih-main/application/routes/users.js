const express = require("express");
const router = express.Router();
const pool = require("../config/db");
const bcrypt = require("bcrypt");

/* GET users listing. */
router.get("/", function (req, res, next) {
  res.send("respond with a resource");
});

router.post("/register", async (req, res, next) => {
  const { username, email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const date = Date.now();
  console.log(username, email, password, hashedPassword);
  pool.query(
    `SELECT username FROM users WHERE username = '${username}';`,
    (err, result) => {
      if (err) throw err;
      console.log(result);
      if (result[0]) {
        res.send({
          status: "error",
          message: "Username already exists!",
        });
      } else {
        pool.query(
          `INSERT INTO users (username, email, password, create_time, update_time) VALUES (?,?,?,?,?);`,
          [username, email, hashedPassword, date, date],
          (err, result) => {
            if (err) {
              res.send({
                status: "error",
                message: "Something went wrong !",
              });
              console.log(err);
            } else {
              pool.query(
                `SELECT id, username, email FROM users WHERE id = '${result.insertId}';`,
                (err, result) => {
                  if (err) {
                    res.send({
                      status: "error",
                      message: "Something went wrong !",
                    });
                  }
                  res.send({
                    status: "success",
                    message: "Successfully registered",
                    user: result[0],
                  });
                }
              );
            }
          }
        );
      }
    }
  );
});

router.post("/login", (req, res, next) => {
  const { username, password } = req.body;
  console.log(username, password);
  pool.query(
    `SELECT id, username, email, password FROM users WHERE username = '${username}';`,
    async (err, result) => {
      if (err) throw err;
      if (!result[0]) {
        res.send({
          status: "warning",
          message: "User doesn't exists!",
        });
      } else {
        const hashedPassword = result[0].password;
        console.log(hashedPassword);
        if (await bcrypt.compare(password, hashedPassword)) {
          console.log("---------> Login Successful");
          res.send({
            status: "success",
            message: `${result[0].username} is logged in!`,
            user: {
              id: result[0].id,
              username: result[0].username,
              email: result[0].email,
            },
          });
        } else {
          console.log("---------> Password Incorrect");
          res.send({ status: "error", message: `Invalid Credentials` });
        }
      }
    }
  );
});

module.exports = router;
