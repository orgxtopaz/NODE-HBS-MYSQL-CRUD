﻿const { application } = require("express");
var express = require("express");
var router = express.Router();
const mysql = require("mysql2");
const pool = require("../config/db");



/* GET home page. */

router.get("/", function (req, res, next) {
  res.render("index", { title: "CSC 317 App", name: "Christian J Shih" });
});

router.get("/home", function (req, res, next) {

  let sql = "SELECT * FROM image";
  

     pool.query(sql, (err, results) => {
      if(err) throw err;
      const searchcount = results.length


      res.render("home", { title: "CSC 317 App", name: "Christian J Shih" ,results:results,searchcount:searchcount});
    
  });
   



});

router.get("/login", function (req, res, next) {
  res.render("Login");
});

router.get("/registration", function (req, res, next) {
  res.render("Registration");
});

router.get("/error", function (req, res, next) {
  res.render("error", { message: "CSC 317 App", status: "Christian J Shih" });
});



///VIEW ALL IMAGE
router.get('/viewpost',(req, res) => {
  let sql = "SELECT * FROM image";

  let query = pool.query(sql, (err, results) => {
      if(err) throw err;

      
      res.render('viewpost',{
    
      results: results
     
      
      });


    
  });
});





//ADD IMAGE
router.post('/addImage',(req, res) => {
  let sampleFile;
  let uploadPath;

  if (!req.files || Object.keys(req.files).length === 0) {
    return res.status(400).send('No files were uploaded.');
  }
 // name of the input is sampleFile
 sampleFile = req.files.sampleFile;
 uploadPath = 'public/upload/' + sampleFile.name;

 console.log(sampleFile);
 let currentdate = new Date().toLocaleString();



 
  // Use mv() to place file on the server
  sampleFile.mv(uploadPath, function (err) {
    if (err)
     return res.status(500).send(err); ///IF ERROR
        const insertImage = "INSERT INTO image SET ?";

        ///IF NOT THEN
        let data = {image: ["public/upload/"+sampleFile.name], title: req.body.title,author:req.body.author,description:req.body.description,create_time:currentdate };

        pool.query(insertImage, data,(err, results) => {
        if(err) throw err;
        res.redirect('home');
       
      });
    
    });



  
});


//ADD COMMENT

 router.post('/addComments',(req, res) => {

  const find = "SELECT comments FROM image WHERE ImageID="+req.body.ImageID+" ";
     
      pool.query(find, (err, results) => {
      if(err) throw err;
      
  
      const joinComments =  "💬"+ req.body.username +" ⮞ "+ req.body.comments+" , "+results[0].comments 

      console.log(req.body.ImageID+req.body.username)

      const sql = "UPDATE image SET comments='"+joinComments+"' WHERE ImageID="+req.body.ImageID;
       pool.query(sql, (err, results) => {
        if(err) throw err;
        res.redirect('viewpost');
      });



    
  });


});




//SEARCH IMAGE

router.post('/search',(req, res) => {
  let imageTitle= req.body.title

  let sql = `SELECT * FROM image WHERE title = "${imageTitle}"`


  let query = pool.query(sql, (err, results) => {
      if(err) throw err;

      const searchcount = results.length

      
      res.render('searchview',{
    
      results: results,
      searchcount: searchcount
     
      
});





    
  });
});



///VIEW SPECIFIC IMAGE VIA ID 

router.post('/viewspecificpost',(req, res) => {
  let imageID= req.body.postview

  let sql = `SELECT * FROM image WHERE ImageID = "${imageID}"`


  let query = pool.query(sql, (err, results) => {
      if(err) throw err;

      const searchcount = results.length

      
      res.render('searchview',{
    
      results: results,
      searchcount: searchcount
      
    });





    
  });
});



 



module.exports = router;
