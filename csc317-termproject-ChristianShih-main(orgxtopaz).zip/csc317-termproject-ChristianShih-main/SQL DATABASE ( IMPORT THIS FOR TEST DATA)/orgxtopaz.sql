-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2021 at 04:42 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orgxtopaz`
--

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `ImageID` int(11) NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`ImageID`, `image`, `title`, `description`, `comments`, `create_time`, `author`) VALUES
(1, 'public/upload/cat1.jpg', 'First Cat Post', 'This is my first cat post', '💬orgxtopaz ⮞ nice cat  , 💬monkeyking ⮞ I love this 1 , ', '11/22/2021, 11:30:44 AM', 'monkeyking'),
(2, 'public/upload/cat2.jpg', 'Second Cat Post', 'My Second Cat Post', '💬orgxtopaz ⮞ nice cat wow , 💬monkeyking ⮞ I love this two , ', '11/22/2021, 11:31:31 AM', 'monkeyking'),
(3, 'public/upload/cat3.jpg', 'Third Cat Post', 'My Third Cat Post', '💬monkeyking ⮞ I love this 3 , ', '11/22/2021, 11:32:00 AM', 'monkeyking'),
(4, 'public/upload/dog1.jpg', 'First Dog Post', 'My first Dog Post', '💬orgxtopaz ⮞  are you ready? , 💬orgxtopaz ⮞ thank you my friend , 💬monkeyking ⮞ nice dog , ', '11/22/2021, 11:38:01 AM', 'orgxtopaz'),
(5, 'public/upload/dog2.jpg', 'Second Dog Post', 'My second Dog Post', '💬monkeyking ⮞ nice dog pitbulllll :)  , ', '11/22/2021, 11:38:24 AM', 'orgxtopaz'),
(6, 'public/upload/dog3.jpg', 'Third Dog Post', 'My Third Dog post', '💬monkeyking ⮞ so cute , ', '11/22/2021, 11:38:50 AM', 'orgxtopaz');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` text DEFAULT NULL,
  `create_time` text DEFAULT NULL,
  `update_time` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `create_time`, `update_time`) VALUES
(1, 'orgxtopaz', 'orgxtopaz@gmail.com', '$2b$10$1vRulyVY6omj0hkKYKCUx.a.G4bCn21SjYCmTOQCPejJ.CKoBjLwW', '1637545416337', '1637545416337'),
(2, 'monkeyking', 'monkeyking@gmail.com', '$2b$10$BO/Xx1Am6ifwUe1yLSzSJuaMkVEjmwcijIdjN3jjiYZw3tPzh0cNK', '1637546858766', '1637546858766');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`ImageID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `ImageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
