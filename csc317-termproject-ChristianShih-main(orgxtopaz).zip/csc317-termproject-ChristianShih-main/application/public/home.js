function loadPhotos() {
  console.log("helo");
  // ajax instance
  var xhr = new XMLHttpRequest();
  xhr.responseType = "json";
  // url
  xhr.open("GET", "https://jsonplaceholder.typicode.com/albums/2/photos", true);
  xhr.onreadystatechange = function () {
    console.log(this.readyState);
    if (this.readyState == 4 && this.status == 200) {
      var jsonResponse = xhr.response;
      document.getElementById("totalCount").innerHTML = jsonResponse.length;
      for (var i = 0; i < jsonResponse.length; i++) {
        display(jsonResponse[i].url, jsonResponse[i].title, jsonResponse[i].id);
      }
    }
  };
  xhr.send();
}

// display function
function display(jso, title, id) {
  var div = document.createElement("div");
  div.setAttribute("class", "makeinline");
  div.setAttribute("id", "childdiv" + id);

  var button = document.createElement("button");
  button.setAttribute("onClick", "callme(this)");
  button.setAttribute("id", id);
  // image
  var img = document.createElement("img");
  img.setAttribute("src", jso);
  img.style.maxWidth = "30vw"
  img.style.minWidth = "20vw"
  button.appendChild(img);

  // title
  var p = document.createElement("p");
  var t = document.createTextNode(title.substr(1,50) + "...");
  p.appendChild(t);
  div.appendChild(button);
  div.appendChild(p);

  // add to main div
  document.getElementById("ajaxValue").appendChild(div);
}
// remove function
function callme(event) {
  console.log(event.id);
  document
    .getElementById("ajaxValue")
    .removeChild(document.getElementById("childdiv" + event.id));
  document.getElementById("totalCount").innerHTML -= 1;
}
