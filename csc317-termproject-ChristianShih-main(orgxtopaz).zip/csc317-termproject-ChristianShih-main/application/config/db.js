const mysql = require("mysql2");
const dotenv = require("dotenv");
dotenv.config();

const pool = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'orgxtopaz'
});


// pool.getConnection(function (err, connection) {
//   if (err) throw err; // not connected!
//   console.log("db connected");
// });

const sql = `CREATE TABLE IF NOT EXISTS users(id int NOT NULL primary key AUTO_INCREMENT, username varchar(255), email VARCHAR(255), password TEXT, create_time TEXT,  update_time TEXT ) default charset utf8`;




const image =
`CREATE TABLE IF NOT EXISTS image (
  ImageID int NOT NULL primary key AUTO_INCREMENT, image varchar(255), title VARCHAR(255),description VARCHAR(255),  comments VARCHAR(255) NOT NULL, create_time VARCHAR(255) ,  author VARCHAR(255)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci;`
pool.query(sql, function (err, result) {
  if (err) throw err;
  console.log("Table created");
});


pool.query(image, function (err, result) {
  if (err) throw err;
  console.log("Table created");
});


module.exports = pool;
