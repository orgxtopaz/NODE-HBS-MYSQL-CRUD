if(localStorage.getItem("user")!=null){
  window.location.replace("/");
}

document.myForm.onsubmit = (e) => {
  e.preventDefault();
  const value = {
    username: document.myForm.username.value,
    password: document.myForm.password.value,
  };
  var xhr = new XMLHttpRequest();
  // url
  xhr.open("POST", "/users/login", true);
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var jsonResponse = JSON.parse(xhr.response);
      if (jsonResponse.status === "error") {
        document.myForm.password.value = "";
        alert(jsonResponse.message);
      } else if (jsonResponse.status === "warning") {
        document.myForm.username.value = "";
        alert(jsonResponse.message);
      } else {
        if (jsonResponse.status === "success") {
          window.location.replace("/");
          let user = jsonResponse.user;
          localStorage.setItem("user", JSON.stringify(user));
          localStorage.setItem("username", JSON.stringify(user.username));
        } else {
          alert("Something went wrong !");
        }
      }
    }
  };
  xhr.send(JSON.stringify(value));
};
